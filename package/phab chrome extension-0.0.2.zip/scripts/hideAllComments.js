"use strict";function hideAllComments(){var e=$(".differential-inline-comment");e.hide()}hideAllComments();
//# sourceMappingURL=hideAllComments.js.map
